<?php include 'header.php';?>

    <?php include $page_name.'.php';?>
    
	
<?php include 'footer.php';?>